#!/bin/bash
PLATFORM=Dos
export DECKY_PLUGIN_RUNTIME_DIR="${HOME}/homebrew/data/Junk-Store"
source "${HOME}/homebrew/data/Junk-Store/scripts/settings.sh"
run_dosbox $@