# junk-scripts

This repo houses my person script backend for the decky junk-store plugin.
