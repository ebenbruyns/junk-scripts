#!/bin/bash
cd ~/Games/exo/
python3 -m http.server 9000
