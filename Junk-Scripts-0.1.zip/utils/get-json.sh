#!/bin/bash
source "${HOME}/bin/settings.sh"
cat "${DECKY_PLUGIN_RUNTIME_DIR}/static-json/${1}.json"
